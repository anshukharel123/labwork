package Lab_3;

import java.util.Random;

/**
 * Driver class. This class demonstrates the functionality of the stats class by
 * generating random numbers and performing various statistical oeperations on
 * them.
 * 

 */
public class Driver {

	/**
	 * This main method creates a Stats object, adds random values to it and then
	 * prints various statistics based on the generated numbers.
	 * 
	 * @param args Command-line arguments.
	 */
	public static void main(String[] args) {

		// Constant to initialize the object by passing the capacity of the array.
		final int VALUES = 10;

		// Creating a Stats object with a capacity of VALUES for the array.
		Stats stats = new Stats(VALUES);

		// Initializing a Random object for generating random numbers.
		Random random = new Random();

		// Generate and add random numbers to the numbers array.
		for (int i = 0; i < VALUES; i++) {

			stats.addValueToNumbersArray(random.nextInt(100));
		}

		System.out.println("Numbers stored : ");

		System.out.println(stats);

		System.out.println("Average = " + stats.getAverage());

		System.out.println("Count = " + stats.getCount());

		System.out.println("Total = " + stats.getTotal());

		System.out.println("Minimum value = " + stats.getMaximumNumber());

		System.out.println("Maximum value = " + stats.getMinimumNumber());
	}
}
