package Lab_3;

import java.util.Arrays;

/**
 * Stats class. This class is designed to perform statistics operations on an
 * array of integeres.
 * 

 */
public class Stats {
	/**
	 * Integer type array to store numbers.
	 */
	private int[] numbers;

	/**
	 * Count of elements in the array.
	 */
	private int count;

	/**
	 * Constructor
	 * 
	 * This constructor is used to initialize the numbers array with
	 * the given capacity of elements.
	 * 
	 * @param capacity The capacity or the number of elements in the array.
	 */
	public Stats(int capacity) {

		numbers = new int[capacity];
	}

	/**
	 * This method adds the given value to the numbers array and increments the
	 * count.
	 * 
	 * @param value The value to be added to the array.
	 */
	public void addValueToNumbersArray(int value) {
		numbers[count] = value;
		count++;
	}

	/**
	 * This method is used to get the count of elements in the numbers array.
	 * 
	 * @return The count of elements in the array.
	 */
	public int getCount() {

		return numbers.length;
	}

	/**
	 * Finds and returns the number with maximum value in the numbers array.
	 * 
	 * @return The maximum number in the array.
	 */
	public int getMaximumNumber() {

		int maximumNumber = numbers[0];

		// Iterate through the array to find the maximum number.
		for (int i = 1; i < numbers.length; i++) {
			if (numbers[i] > maximumNumber)
				maximumNumber = numbers[i];
		}

		return maximumNumber;
	}

	/**
	 * Finds and returns the minimum number in the numbers array.
	 * 
	 * @return The minimum number in the numbers array.
	 */
	public int getMinimumNumber() {

		int minimumNumber = numbers[0];

		// Iterate through the array to find the minimum number.
		for (int i = 1; i < numbers.length; i++) {
			if (numbers[i] < minimumNumber)
				minimumNumber = numbers[i];
		}

		return minimumNumber;
	}

	/**
	 * This method calculates and returns the total sum of all the numbers in the
	 * array.
	 * 
	 * @return The total sum of all numbers in the array.
	 */
	public int getTotal() {

		int total = 0;

		// Iterate through the array adding the elements into total.
		for (int i = 0; i < numbers.length; i++) {
			total += numbers[i];
		}
		return total;
	}

	/**
	 * This method calculates and returns the average of all numbers in the array.
	 * 
	 * @return The average of all elements in the array.
	 */
	public double getAverage() {

		int sum = 0;

		// Calculate the sum of all values within the array.
		for (int i = 0; i < numbers.length; i++) {
			sum += numbers[i];
		}

		// Calculate and return the average.
		double average = sum / (double) numbers.length;

		return average;
	}

	@Override
	public String toString() {
		return Arrays.toString(numbers);
	}

}
