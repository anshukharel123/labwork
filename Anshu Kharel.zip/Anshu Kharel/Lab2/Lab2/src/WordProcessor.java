import java.util.Objects;

/**
 * WordProcessor class. This class implements the <{@link Counter} interface and
 * provides methods for counting and analyzing words, letters and the length of
 * text.
 * 

 */
public class WordProcessor implements Counter {

	/**
	 * A fall-back text. This text is used in case sentence provided is null.
	 */
	private String text;

	/**
	 * Gets the current fall-back text stored in the WordProcessor.
	 * 
	 * @return The current fall-back text.
	 */
	public String getText() {
		return text;
	}

	/**
	 * Sets the fall-back text in the WordProcessor.
	 * 
	 * @param text The fall-back text to set.
	 */
	public void setText(String text) {
		this.text = text;
	}

	@Override
	public int countWords(String sentence) {
		if (sentence == null) {
			sentence = text;
		}
		String[] strings = sentence.split(" ");
		int numberOfWords = strings.length;
		return numberOfWords;
	}

	@Override
	public int countLetters(String sentence) {
		if (sentence == null) {
			sentence = text; // Setting fall-back text.
		}

		int numberOfLetters = 0;

		/*
		 * For loop for iterating through every letters of the sentence and checking if
		 * it is a letter or not.
		 */
		for (int i = 0; i < sentence.length(); i++) {
			if (Character.isLetter(sentence.charAt(i))) {
				numberOfLetters++;
			}
		}

		return numberOfLetters;
	}

	@Override
	public int getLength(String sentence) {
		if (sentence == null) {
			sentence = text;
		}
		return sentence.length();
	}

}
