import java.util.Scanner;

/**
 * Driver Class. This class is used for testing the WordProcessor and Counter functionality.
 * 
 
 */
public class Driver {
	
	/**
	 * This is the main method of the application, where user input is taken and WordProcessor
	 * functionality is tested.
	 */
	public static void main(String[] args) {
		
		// Scanner object to take user input.
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a sentence: ");
		String inputString = scanner.nextLine();
		scanner.close();

		WordProcessor wordProcessor = new WordProcessor();
		wordProcessor.setText("Fallback text");

		// Testing WordProcessor methods with user input.
		System.out.println("Number of words: " + wordProcessor.countWords(inputString));
		System.out.println("Number of letters: " + wordProcessor.countLetters(inputString));
		System.out.println("Length of sentence: " + wordProcessor.getLength(inputString));

		// Testing WordProcessor methods with null values.
		System.out.println("\n\nTesting with null values\n");
		System.out.println("Numer of words: " + wordProcessor.countWords(null));
		System.out.println("Number of letters: " + wordProcessor.countLetters(null));
		System.out.println("Length of sentence: " + wordProcessor.getLength(null));

		// Changing the data type of the WordProcessor instance to be Counter.
		Counter counter = wordProcessor; // Upcasting
		
		// Testing WordProcessor methods with user input.
		System.out.println("\n\nAfter changing the data type to Counter.");
		System.out.println("\nNumber of words: " + wordProcessor.countWords(inputString));
		System.out.println("Number of letters: " + wordProcessor.countLetters(inputString));
		System.out.println("Length of sentence: " + wordProcessor.getLength(inputString));
		
		// Testing WordProcessor methods with null values.
		System.out.println("\n\nTesting with null values\n");
		System.out.println("Numer of words: " + wordProcessor.countWords(null));
		System.out.println("Number of letters: " + wordProcessor.countLetters(null));
		System.out.println("Length of sentence: " + wordProcessor.getLength(null));

	}

}
