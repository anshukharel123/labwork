import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

class TriangleTest {

	@BeforeEach
	void createInstance() {
		Triangle triangle = new Triangle();
	}

	@Test
	void testIsIsosceles() {
		Triangle triangle = new Triangle();
		assertFalse(triangle.isIsosceles()); // By default, triangle is not isosceles.
	}

	@Test
	void testIsEquilateral() {
		Triangle triangle = new Triangle();
		assertTrue(triangle.isEquilateral());
	}

	@Test
	void testIsScalene() {
		Triangle triangle = new Triangle();
		assertFalse(triangle.isScalene()); // By default, triangle is not scalene.
	}

	/*
	 * Testing setSides() method by passing arguments to make an equilateral
	 * triangle.
	 */
	@Test
	void testSetSidesWithThreeParameters() {
		Triangle triangle = new Triangle();

		triangle.setSides(2, 2, 3);
		assertTrue(triangle.isIsosceles());
	}

	@Test
	void testSetSidesWithThreeParametersWithNegativeValues() {
		Triangle triangle = new Triangle();

		triangle.setSides(-2, 2, 3);
		assertTrue(triangle.isIsosceles());
	}

	@ParameterizedTest
	@CsvSource({ "2, 4, 5", "2, -4, -5" })
	void testSetSidesWithThreeParametersScalene(int sideA, int sideB, int sideC) {
		Triangle triangle = new Triangle();

		triangle.setSides(sideA, sideB, sideC);
		assertTrue(triangle.isScalene());
	}

	/*
	 * Testing setSides() method by passing arguments to make an equilateral
	 * triangle.
	 */
	@ParameterizedTest
	@ValueSource(ints = { 7, -7 })
	void testSetSidesForEquilateral(int sideLength) {
		Triangle triangle = new Triangle();

		triangle.setSides(sideLength);
		assertTrue(triangle.isEquilateral());
	}

	/**
	 * In below code setSides() method says it sets scalene triangle according to
	 * its comments But in actual this method sets an isosceles triangle. Hence, the
	 * boolean value returned by isScalene() is false.
	 */
	@Test
	void testSetSidesForScalene() {
		Triangle triangle = new Triangle();

		triangle.setSides(5, 8); // As it sets the triangle to be isosceles.
		assertFalse(triangle.isScalene());
	}

	/*
	 * Testing copy() method by chjecking if it is returning the a copy of a
	 * triangle.
	 */
	@Test
	void testCopy() {
		Triangle triangle = new Triangle();

		Triangle copiedTriangle = triangle.copy();

		assertNotSame(triangle, copiedTriangle); // Checking if the copied triangle has a new instance

		// Checking if they have same properties
		assertEquals(copiedTriangle.isEquilateral(), triangle.isEquilateral());

		// Changing the side lengths of the copied triangle.
		copiedTriangle.setSides(1, 2, 3);

		// The result is not equal as copied triangle and triangle doesn't share the
		// same memory.
		assertNotEquals(copiedTriangle.isEquilateral(), triangle.isEquilateral());
	}

	@ParameterizedTest
	@CsvSource({ "2, 3, 4", "4, 5, 8", "1, 1, 1", "3, 8, 9", "8, 4, 10" })
	void testGetPerimeter(int sideA, int sideB, int SideC) {
		Triangle triangle = new Triangle();

		triangle.setSides(sideA, sideB, SideC);
		assertEquals((sideA + sideB + SideC), triangle.getPerimeter());
	}

	@RepeatedTest(10)
	void testGetAverageLength(RepetitionInfo repetitionInfo) {
		Triangle triangle = new Triangle();

		int repCount = repetitionInfo.getCurrentRepetition();

		triangle.setSides(repCount, repCount + 3, repCount + 3);
		assertEquals((repCount + repCount + 3 + repCount + 3) / 3, triangle.getAverageLength());
	}

	/**
	 * Trying to set the triangle to be scalene.
	 */
	@Test
	void testTriangleConstructorWithThreeParameters() {
		Triangle triangle = new Triangle(1, 5, 4);

		assertTrue(triangle.isScalene());
	}

	@Test
	void testTriangleConstructorWithThreeParametersHavingNegativeValues() {
		Triangle triangle = new Triangle(1, 5, 4);

		assertTrue(triangle.isScalene());
	}

	/**
	 * Trying to set the triangle to be isosceles.
	 */
	@ParameterizedTest
	@CsvSource({ "4, 4, 7", "4, -4, -7" })
	void testTriangleConstructorWithThreeParametersForIsosceles(int sideA, int sideB, int SideC) {
		Triangle triangle = new Triangle(sideA, sideB, SideC);
		assertTrue(triangle.isIsosceles());
	}

	@ParameterizedTest
	@ValueSource(ints = { 5, -5 })
	void testTriangleConstructorWithOneParameter(int sideLength) {
		Triangle triangle = new Triangle(sideLength);
		assertTrue(triangle.isEquilateral());
	}

	@Test
	void testDefaultTriangleConstructor() {
		Triangle triangle = new Triangle();
		assertTrue(triangle.isEquilateral());
	}
}
